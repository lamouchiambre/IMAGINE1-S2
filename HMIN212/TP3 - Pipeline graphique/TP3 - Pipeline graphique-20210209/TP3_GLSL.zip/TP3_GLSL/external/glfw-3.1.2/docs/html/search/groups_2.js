var searchData=
[
  ['initialization_2c_20version_20and_20errors',['Initialization, version and errors',['../group__init.html',1,'']]],
  ['input_20handling',['Input handling',['../group__input.html',1,'']]]
];
