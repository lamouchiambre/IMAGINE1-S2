// Sachin Shah
// March 10, 2020
// Utility methods

#ifndef _UTILS_H
#define _UTILS_H

void error(char *msg);
void check_null(void *ptr, char *msg);

#endif