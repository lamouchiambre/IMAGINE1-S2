# GridImageSegmentation
Repository for source code from my master's degree thesis: "Image segmentation using PLGrid infrastructure".
