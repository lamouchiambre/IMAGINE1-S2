package tsp;

public class AlgoGenTSP{
	public class Individu implements Comparable<Individu> {

		Individu(){

		}

		public int compareTo(Individu compare) {
			// a remplir retourne 0 si egaux, negatif si plus petit, positif si plus grand 
		   return 0;
		}
	}

	public AlgoGenTSP(int dist[][],int nbVilles){
		
	}
}
